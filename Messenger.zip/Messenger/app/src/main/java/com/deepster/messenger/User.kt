package com.deepster.messenger


class User(val uid : String, val username: String, val profileImageURL : String)